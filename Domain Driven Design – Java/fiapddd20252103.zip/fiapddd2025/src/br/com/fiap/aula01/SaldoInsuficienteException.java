package br.com.fiap.aula01;

public class SaldoInsuficienteException extends Exception {

	public SaldoInsuficienteException(String message) {
		super(message);
	}
	
}
