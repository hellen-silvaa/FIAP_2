package br.com.fiap.aula04.banco.conta.entidade;

public class Conta {

}
