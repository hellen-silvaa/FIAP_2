package br.com.fiap.aula0301;

public class Pagamento {
	
	public void pagar(TipoPagamento tipoPagamento) {
		tipoPagamento.pagar();
	}

}
