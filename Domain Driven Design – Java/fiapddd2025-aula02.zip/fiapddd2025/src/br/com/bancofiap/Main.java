package br.com.bancofiap;

import br.com.bancofiap.modelo.Banco;
import br.com.bancofiap.modelo.Cliente;
import br.com.bancofiap.modelo.ContaComum;
import br.com.bancofiap.modelo.ContaEspecial;
import br.com.bancofiap.modelo.ContaRemunerada;

public class Main {
	
	public static void main(String[] args) {
		
		Banco banco = new Banco();
		banco.setNome("Banco FIAP");
		
		Cliente cliente = new Cliente();
		cliente.setNome("Anderson Fonseca");
		
		Cliente clienteEspecial = new Cliente();
		clienteEspecial.setNome("Maria Fonseca");
		
		ContaComum contaComum = banco.criar("123456-0", cliente, 100.00);
	
		ContaEspecial contaEspecial = banco.criar("789123-0", clienteEspecial, 1000, 100.00);
		
		ContaRemunerada contaRemunerada = banco.criar("999999-9", 1.20, clienteEspecial, 100.00);
		contaRemunerada.remunerarConta();
		
		System.out.println("O saldo da conta numero " + contaComum.getNumero() +
				      " do cliente " + contaComum.getCliente().getNome() + "  eh " + contaComum.obterSaldo());

		System.out.println("O saldo da conta especial numero " + contaEspecial.getNumero() +
				" do cliente " + contaEspecial.getCliente().getNome() + " eh " + contaEspecial.obterSaldo());

		System.out.println("O saldo da conta remunerada numero " + contaRemunerada.getNumero() +
				" do cliente " + contaRemunerada.getCliente().getNome() + " eh " + contaRemunerada.obterSaldo());

		
	}

}
