package br.com.bancofiap.modelo;

public class ContaRemunerada extends ContaComum {

	private double taxaRemuneracao = 0.0;
	
	public double saldoRemunerado;
	
	public ContaRemunerada(Banco banco, Cliente cliente, String numero, double saldo, double taxaRemuneracao) {
		super(banco, cliente, numero, saldo);
		this.taxaRemuneracao = taxaRemuneracao;
	}	
	
	public double getTaxaRemuneracao() {
		return taxaRemuneracao;
	}

	public void remunerarConta() {
		saldoRemunerado = super.obterSaldo() * this.taxaRemuneracao;
	}
	
	public double obterSaldo() {
		return this.saldoRemunerado;
	}
	
}
