package br.com.fiap;

public class Main {
	
	public static void main(String[] args) {
				
		// cast
		
		Animal animal = new Gato();
		animal.setNome("Garrafa");
		animal.fazerSom();
		
		
	}
	

}
