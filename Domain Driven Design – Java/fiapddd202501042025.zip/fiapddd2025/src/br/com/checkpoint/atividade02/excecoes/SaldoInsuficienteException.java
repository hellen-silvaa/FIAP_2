package br.com.checkpoint.atividade02.excecoes;

public class SaldoInsuficienteException extends Exception {

	public SaldoInsuficienteException(String message) {
		super(message);
	}
	
}
