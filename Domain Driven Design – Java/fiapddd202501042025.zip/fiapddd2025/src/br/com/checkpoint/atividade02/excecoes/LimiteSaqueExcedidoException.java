package br.com.checkpoint.atividade02.excecoes;

public class LimiteSaqueExcedidoException extends Exception {
	
	public LimiteSaqueExcedidoException(String message) {
		super(message);
	}

}
