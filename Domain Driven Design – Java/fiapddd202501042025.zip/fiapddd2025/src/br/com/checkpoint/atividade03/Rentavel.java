package br.com.checkpoint.atividade03;

public interface Rentavel {

	public void calcularRendimento();
	
}
