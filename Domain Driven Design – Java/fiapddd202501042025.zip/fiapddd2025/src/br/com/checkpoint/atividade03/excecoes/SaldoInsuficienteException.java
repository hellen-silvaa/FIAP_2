package br.com.checkpoint.atividade03.excecoes;

public class SaldoInsuficienteException extends Exception {

	public SaldoInsuficienteException(String message) {
		super(message);
	}
	
}
