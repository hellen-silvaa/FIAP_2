package br.com.checkpoint.atividade03;

public interface Imposto {
		
	public void calcularImposto();

}
