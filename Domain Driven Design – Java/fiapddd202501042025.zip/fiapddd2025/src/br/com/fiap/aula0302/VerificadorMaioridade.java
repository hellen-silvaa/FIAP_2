package br.com.fiap.aula0302;

public class VerificadorMaioridade {

	public String verificar(int idade) {
		return idade >= 18 ? "Maioridade" : "Menoridade";
	}
	
}
