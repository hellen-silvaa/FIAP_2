package br.com.fiap.aula0402;

public class Animal {
	
	public void fazerSom() {
		System.out.println("Som do animal!!");
	}

}
