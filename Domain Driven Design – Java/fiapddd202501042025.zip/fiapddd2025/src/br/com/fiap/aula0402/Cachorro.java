package br.com.fiap.aula0402;

public class Cachorro extends Animal {
	
	public void fazerSom() {
		System.out.println("Latindo!!");
	}

}
