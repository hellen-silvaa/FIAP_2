package br.com.fiap.aula0402;

public class Gato extends Animal {
	
	public void fazerSom() {
		System.out.println("Miando!!");
	}

}
