package br.com.fiap.aula0301;

public interface TipoPagamento {
	
	public void pagar();

}
