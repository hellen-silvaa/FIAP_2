package br.com.fiap.aula04.banco.cliente.entidade;

public class Conta {

}
