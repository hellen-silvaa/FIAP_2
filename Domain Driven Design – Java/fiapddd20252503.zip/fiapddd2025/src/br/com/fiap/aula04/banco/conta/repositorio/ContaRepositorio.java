package br.com.fiap.aula04.banco.conta.repositorio;

public class ContaRepositorio {

}
