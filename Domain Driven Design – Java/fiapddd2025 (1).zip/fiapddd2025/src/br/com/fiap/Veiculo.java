package br.com.fiap;

public class Veiculo {
	
	private String modelo;
	
	private String marca;
	
	private int anoFabricacao;

	public String getModelo() {
		return modelo;
	}

	public void setModelo(String modelo) {
		this.modelo = modelo;
	}

	public String getMarca() {
		return marca;
	}

	public void setMarca(String marca) {
		this.marca = marca;
	}

	public int getAnoFabricacao() {
		return anoFabricacao;
	}

	public void setAnoFabricacao(int anoFabricacao) {
		this.anoFabricacao = anoFabricacao;
	}
	
	public void mover() {
		System.out.println("Veiculo movendo...");
	}

	public void parar() {
		System.out.println("Veiculo parado...");
	}
	public void acelerar() {
		System.out.println("Veiculo acelerado...");
	}
	
	public void frear() {
		System.out.println("Veiculo freando...");
	}

	@Override
	public String toString() {
		return "Veiculo [" + (modelo != null ? "modelo=" + modelo + ", " : "")
				+ (marca != null ? "marca=" + marca + ", " : "") + "anoFabricacao=" + anoFabricacao + "]";
	}
	
}
