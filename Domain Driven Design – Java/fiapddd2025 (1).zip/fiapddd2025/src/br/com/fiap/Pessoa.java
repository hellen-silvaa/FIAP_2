package br.com.fiap;

import java.util.Date;

public class Pessoa {

	private String primeiroNome;
	
	private String ultimoNome;
	
	private Date dataNascimento;
	
	public String getPrimeiroNome() {
		return primeiroNome;
	}

	public void setPrimeiroNome(String primeiroNome) {
		this.primeiroNome = primeiroNome;
	}

	public String getUltimoNome() {
		return ultimoNome;
	}

	public void setUltimoNome(String ultimoNome) {
		this.ultimoNome = ultimoNome;
	}

	public Date getDataNascimento() {
		return dataNascimento;
	}

	public void setDataNascimento(Date dataNascimento) {
		this.dataNascimento = dataNascimento;
	}

	@Override
	public String toString() {
		return "Pessoa [" + (primeiroNome != null ? "primeiroNome=" + primeiroNome + ", " : "")
				+ (ultimoNome != null ? "ultimoNome=" + ultimoNome + ", " : "")
				+ (dataNascimento != null ? "dataNascimento=" + dataNascimento : "") + "]";
	}
	
}
