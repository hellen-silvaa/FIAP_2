package br.com.fiap;

import java.util.Date;

public class Main {
	
	public static void main(String[] args) {
		
		Pessoa pessoa = new Pessoa();
		
		pessoa.setPrimeiroNome("Anderson");
		pessoa.setUltimoNome("Fonseca");
		pessoa.setDataNascimento(new Date());
		
		System.out.println(pessoa);
		
		Pessoa alguem = pessoa;
		alguem.setPrimeiroNome("Sophia");
		
		System.out.println(alguem);

		System.out.println(pessoa);
		
		System.out.println("======================================================================");
		
		Veiculo veiculo = new Veiculo();
		veiculo.setMarca("Peugeot");
		veiculo.setModelo("2008");
		veiculo.setAnoFabricacao(2025);
		
		System.out.println(veiculo);
		
		veiculo.acelerar();
		veiculo.parar();
		
		System.exit(0);
				
	}
	

}
