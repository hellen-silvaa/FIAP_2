package br.com.fiap.aula0303;

public class VamoVerNoqueVaiDa {
	
	public static void main(String[] args) {
		
		String[] texto = new String[] {"aaaa", "bbb", "cccc"};

		System.out.println(texto[3]);
		
	}
	
	public void gerarBO() {
		System.out.println("Gerar BO");
		gerarBO();
	}
	

}
