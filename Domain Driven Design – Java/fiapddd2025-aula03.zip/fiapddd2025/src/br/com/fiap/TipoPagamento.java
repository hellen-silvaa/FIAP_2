package br.com.fiap;

public interface TipoPagamento {
	
	public void pagar();

}
