package br.com.fiap;

public class Pagamento {
	
	public void pagar(TipoPagamento tipoPagamento) {
		tipoPagamento.pagar();
	}

}
