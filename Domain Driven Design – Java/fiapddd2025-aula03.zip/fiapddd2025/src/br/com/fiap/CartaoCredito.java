package br.com.fiap;

public class CartaoCredito implements TipoPagamento {

	@Override
	public void pagar() {
		System.out.println("Pagar com Cartao de Credito!!!");
	}

}
