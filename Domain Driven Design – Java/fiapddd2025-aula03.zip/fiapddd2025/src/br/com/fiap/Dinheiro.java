package br.com.fiap;

public class Dinheiro implements TipoPagamento {

	@Override
	public void pagar() {
		System.out.println("Pagar com Dinheiro!!!");
	}

}
