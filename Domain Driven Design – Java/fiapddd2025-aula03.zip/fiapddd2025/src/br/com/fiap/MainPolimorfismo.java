package br.com.fiap;

public class MainPolimorfismo {
	
	public static void main(String[] args) {
		
		TipoPagamento tipoPagamento = new CartaoCredito();

		Pagamento pagamento = new Pagamento();
		pagamento.pagar(tipoPagamento);
		
	}
	
	

}
